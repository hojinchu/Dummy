/*=======================================================
 * 	IDAO.java
 * 	-�������̽�
 */

package com.test.spr;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IDAO
{
	public ArrayList<MemberDTO> lists() throws SQLException, ClassNotFoundException;
	
}
