/*=====================================================
 * 	LocalDAO.java
 * 	 -Ŭ����. IDAO �������̽��� implements�ϴ� Ŭ����.	
 *======================================================*/
package com.test.spr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.jdbc.driver.OracleDriver;

public class LocalDAO implements IDAO
{

	@Override
	public ArrayList<MemberDTO> lists() throws SQLException, ClassNotFoundException
	{
		//OracleDriver
		
		ArrayList<MemberDTO> result=new ArrayList<MemberDTO>();
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url="jdbc:oracle:thin:scott/tiger@localhost:1521:orcl";
		Connection conn=DriverManager.getConnection(url);
		
		String sql="SELECT MID,NAME,TEL FROM TBL_MEMBERLIST ORDER BY MID";
		
		PreparedStatement pstmt=conn.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		
		while(rs.next()) {
			
		}
		
		return result;
	}
	
}






